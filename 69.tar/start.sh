bash ./aria.sh && npm start
